<template>

<img :src="require('@/assets/design.png')" style="float: left; height: 400px">
<p style="font-size: 130%; white-space: pre-line;">
    {{`AI kan gebruikt worden in bijna alles wat mensen kunnen of niet kunnen. Ja, echt bijna alles, AI is dus een soort denkende computer die heel snel dingen aan elkaar kan koppelen. Dat is eigenlijk wat mensen (en dieren) ook doen, ze koppelen gevoel of input aan iets interns en dat reflecteren ze weer in hun gedrag.

Als AI theoretisch alles kan doen wat een mens kan, waarom maken/doen we dat niet en laten we de AI een nachtje aan staan om allemaal wereldproblemen op te lossen?
Helaas werkt het niet zo makkelijk, AI’s worden gemaakt oms pecifieken problemen heel goed/slim op te lossen, zoals: een realistische foto maken, objecten herkennen in een filmpje, code schrijven of een verhaal bedenken. 
Al die voorbeelden zijn allemaal aparte AI’s, die speciaal gemaakt zijn voor die taken (ze kunnen dus niks anders). 

De reden dat je speciaal bent is dat je al die dingen tegelijk (ook al is het in je hoofd, zoals realistische foto’s) kan doen en nog veel meer.  
`}}
</p>

</template>

<script>


export default {
    name: 'WanneerAIPage'
}
</script>

<style>

</style>