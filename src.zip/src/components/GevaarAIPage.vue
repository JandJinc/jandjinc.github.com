<template>


<img :src="require('@/assets/waaromai.jpg')" style="text-align: left; height: 400px">
<p style="font-size: 150%; white-space: pre-line;">
    {{`AI kan ons grootste wapen zijn, maar ook onze grootste vijand. Als je denkt aan een AI die gevaarlijk is komen zogenaamde killer robots al snel op, maar het kan veel simpeler dan dat: bijvoorbeeld door deepfakes je kan zo best wel makkelijk mensen dingen laten zeggen. Dat hebben wij ook bij meneer Breda gedaan. Kijk maar voor jezelf.

Als je daar een “AI-voice” bij doet kan je iemand alles laten zeggen wat je wil. Dit kan erg gevaarlijk worden als je dit doet om je politieke tegenstanders uit te schakelen door ze erge dingen te laten zeggen.


Maar laten we nu teruggaan naar die killer-robots, want velen denken dat dat nog niet mogelijk is, maar die bestaan tegenwoordig ook al. Je kan bijvoorbeeld op drones die een explosief bij zich hebben een gezichtsherkennings programma zetten, die bijvoorbeeld al op je nieuwe iPhone staat. 

Door zulke voorbeelden zijn er veel mensen tegen de ontwikkeling van AI.
`}}
</p>

</template>

<script>


export default {
    name: 'GevaarAIPage'
}
</script>

<style>

</style>