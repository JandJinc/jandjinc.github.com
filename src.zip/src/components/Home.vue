<template>

<img style="text-align: left; height: 400px" :src="require('@/assets/startphotoai.jpg')">

<p style="white-space: pre-line; font-size: 150%">
    {{`AI is een recente ontwikkeling op het gebied van informatica. Hoewel alle mogelijkheden nog niet ontdekt zijn, zijn er wel al veel nuttige toepassingen gevonden.
Op deze website gaan wij u proberen uit te leggen wat AI is, wat het doet, wat de voor- en nadelen zijn en hoe het werkt.
`}}
</p>


</template>

<script>


export default {
    name: 'HomePage'
}
</script>

<style>

</style>