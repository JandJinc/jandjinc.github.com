<template>

<img :src="require('@/assets/2ndphotoai.jpg')" style="float: right; height: 400px" >
<p style="font-size: 130%; white-space: pre-line; float: none">
    {{`Wat is AI: AI oftewel artificial intelligence is een computer programma dat het denkvermogen van mensen na doet. Momenteel is AI nog niet zo goed dat het meerdere functies van mensen over kan nemen, maar het kan wel al enkele overnemen of dingen doen die mensen niet kunnen.

    Denk dan bijvoorbeeld aan bots die het gedrag van mensen kan voorspellen. Een redelijk bekend geval hiervan heeft te maken met Target, een Amerikaanse supermarktketen. Het verhaal gaat als volgt: 

    Er was een tiener meisje, dat allerlei reclames van Target over zwangerschap kreeg. De haar vader had dat door en was er niet blij mee dat zijn dochter reclames daarover kreeg, omdat hij dacht dat Target wou dat zijn dochter zwanger zou worden, daarom stuurde hij een brief.

    In die brief schreef hij dat Target moest stoppen met het sturen van reclames naar zijn dochter.
    Wat bleek nou, Target had een AI-model getraind om op basis van wat klanten kochten te voorspellen of ze zwanger waren. Dat model dacht dus dat zijn dochter zwanger was, en had ook gelijk. Want 6 maanden later beviel zijn dochter met haar eerste kind en bood hij z’n excuses aan Target aan.
    `}}</p>



</template>

<script>


export default {
    name: 'WatAIPage'
}
</script>

<style>

</style>